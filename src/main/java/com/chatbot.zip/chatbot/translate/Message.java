package com.chatbot.translate;

public class Message {
    public String type;
    public String id;
    public String text;
}
