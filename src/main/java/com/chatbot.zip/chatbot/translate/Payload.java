package com.chatbot.translate;

public class Payload {
    public Events[] events;
}
